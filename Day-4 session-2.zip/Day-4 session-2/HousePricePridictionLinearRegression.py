import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.datasets import fetch_california_housing # Use California data
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Load the data
housing = fetch_california_housing()
X = pd.DataFrame(housing.data, columns=housing.feature_names)
y = housing.target # Target is the house value (in $100,000s)

# 2. Split Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
from sklearn.linear_model import LinearRegression
# 1. Initialize
lin_reg = LinearRegression()
# 2. Train
lin_reg.fit(X_train_scaled, y_train)
# 3. Predict
y_pred_lr = lin_reg.predict(X_test_scaled)
from sklearn.ensemble import RandomForestRegressor
# 1. Initialize
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
# 2. Train
rf_reg.fit(X_train_scaled, y_train)
# 3. Predict
y_pred_rf = rf_reg.predict(X_test_scaled)
mse_lr = mean_squared_error(y_test, y_pred_lr)
mae_lr = mean_absolute_error(y_test, y_pred_lr)
r2_lr = r2_score(y_test, y_pred_lr)
print(f"Linear Reg: MSE={mse_lr:.4f}, MAE={mae_lr:.4f}, R2={r2_lr:.4f}")
mse_rf = mean_squared_error(y_test, y_pred_rf)
mae_rf = mean_absolute_error(y_test, y_pred_rf)
r2_rf = r2_score(y_test, y_pred_rf)
print(f"Random Forest: MSE={mse_rf:.4f}, MAE={mae_rf:.4f}, R2={r2_rf:.4f}")

#Metric	                    What it Measures	                                                                                           Interpretation (Lower is better)
#Mean Absolute Error (MAE)	The average magnitude of errors in a set of predictions.	                                                   Represents the average absolute dollar amount the prediction is off by (e.g., if MAE is 0.5, the model is off by $50,000).
#Mean Squared Error (MSE)	The average of the squared errors.                                                                             Penalizes large errors heavily. Useful when large prediction errors are especially undesirable.
#**R-squared (R2) Score**	The proportion of the variance in the dependent variable that is predictable from the independent variables.   Ranges from 0 to 1. Closer to 1 is better (e.g., R2 of 0.8 means the model explains 80% of the variance).