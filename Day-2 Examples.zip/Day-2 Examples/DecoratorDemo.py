def My_Decorator(original_function):
    def wrapper_function():
        print(f"Wrapper executed before {original_function.__name__}")
        original_function()
        print(f"Wrapper executed after {original_function.__name__}")
    return wrapper_function
@My_Decorator
def say_hello():
    print("Hello!")
@My_Decorator
def say_hi():
    print("hi!")


say_hi()
say_hello()