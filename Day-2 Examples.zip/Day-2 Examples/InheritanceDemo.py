class Employee:
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary

    def get_salary(self):
        return self.salary

    def set_salary(self, new_salary):
        self.salary = new_salary
    def m1(self):
        print("parent m1 method")
    def __str__(self):
        return f"Employee: {self.name}, Salary: ${self.salary:.2f}"
    
class Manager(Employee):
    def __init__(self, name, salary, department):
        super().__init__(name, salary)
        self.department = department
    def m1(self):
        super().m1()
        print("child m1 method")
    def __str__(self):
        
        return f"Manager: {self.name}, Salary: ${self.salary:.2f}, Department: {self.department}"
    
mgr=Manager("Bob", 80000, "Sales")
mgr.set_salary(85000)
mgr.m1()
print(mgr)


