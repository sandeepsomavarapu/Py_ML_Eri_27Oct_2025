class Dog:
    def speak(self):
        return "Woof!"
class Cat:
    def speak(self):
        return "Meow!"
class PetFactory:
    @staticmethod
    def get_pet(pet_type):
        if pet_type == "dog":
            return Dog()
        elif pet_type == "cat":
            return Cat()
        else:
            return None       
factory=PetFactory()    
print(factory.get_pet("dog").speak())   
print(factory.get_pet("cat").speak())   