def count(max):
    count = 1
    while count <= max:
        yield count
        count += 1
for number in count(5):
    print(number)        