class Duck:
    def eat(self):
        print("Eating bread")
    def talk(self):
        print("Quack!")
class Dog(Duck):
    def talk(self):
        print("Woof!")

d=Dog()
d.eat()
d.talk()
