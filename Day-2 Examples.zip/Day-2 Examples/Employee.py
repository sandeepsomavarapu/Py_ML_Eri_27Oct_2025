class Employee:
    """"A class to represent an Employee."""
    orgName='XYZ Pvt Ltd'#static/class variable  
    def __init__(self,eid,ename,esal):
        self.eid=eid#instance variable
        self.ename=ename
        self.esal=esal
        result=12+13
        print("Employee class constructor",result)
    def getSalary(self):
        self.designation='Manager'#instance variable
        print("Employee Salary is:",self.esal)

    def getInfo(self):
        print("Employee ID:",self.eid)
        print("Employee Name:",self.ename)
        self.getSalary()
    @classmethod
    def walk(cls):
        cls.orgName='ABC Pvt Ltd'#static variable access
        print("Employee is walking")  
        
    @staticmethod
    def add(a,b):
        return a+b

print("Organization Name:",Employee.orgName)#static variable access
obj=Employee(123,'suresh',45000)
obj.getSalary()
obj.getInfo()
obj.add(10,20)#static method call by object
print("Addition is:",Employee.add(30,40))#static method call by class
obj.walk()#calling class method
Employee.walk()#calling class method
obj.email='suresh@gmail'#instance variable
print("EMployer Name",obj.orgName)
obj1=Employee(124,'naresh',55000)
print(obj1.ename)
