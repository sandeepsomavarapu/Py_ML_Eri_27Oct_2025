print("welcome to the application!")

empName=input("Enter your name: ")  
print("Thank you for providing your name.",empName)

def greet_user(name):
    print("Hello, {name}! Welcome aboard.")
    print("We're glad to have you with us.")
def add(a, b):
    return a + b

print("Starting user greeting...")
greet_user(empName)
greet_user("rahul")
result = add(5, 10)
print(f"The sum of 5 and 10 is: {result}")

emps=["Alice", "Bob", "Charlie"]
for emp in emps:
    print(f"Employee Name: {emp}")