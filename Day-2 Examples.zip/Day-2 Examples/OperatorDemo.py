from abc import *
class Vehicle(ABC):
    @abstractmethod
    def noOfWheels(self):
        pass
    def vehicleType(self):#concrete method
        return "Vehicle"
class Car(Vehicle):
    def noOfWheels(self):
        return 4
    def carType(self):
        return "Sedan"
car=Car()
print(car.noOfWheels())
print(car.carType())