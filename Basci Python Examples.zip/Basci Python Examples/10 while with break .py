# Python Break Statement in While Loop Example

i = 0
while i <= 10:
	print(" The Value of the Variable i =  ", i)
	i = i + 1
	if i == 4:
		break
