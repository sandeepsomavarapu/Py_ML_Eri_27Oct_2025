# Python For Loop - String Example

# name='chintu'
# names[]={'shanmuka shiva','chintu','shiva'}.....
# Python For Loop - List Example
Countries = ['India', 'U K', 'U S A', 'Australia']
for Country in Countries: # Second For Loop
    print("Countries are: ", Country)
    
print("---This is Outside List For Loop")
Str = "welcome to programming"#  -1
for char in Str: # First For Loop
    print("Letters are: ", char)
  
print("----This is Outside String For Loop---")
print(" ")



# Python For Loop with Range Example

for number in range(0,5):
    print("Current Number: ", number)
	
	
	
	
	
	
	
	

